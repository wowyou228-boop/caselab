import crypto from "node:crypto";

export function verifyTelegramInitData(initData, botToken) {
  if (!initData || !botToken) throw new Error("Telegram initData или BOT_TOKEN отсутствует");
  const params = new URLSearchParams(initData);
  const hash = params.get("hash");
  if (!hash) throw new Error("В initData нет hash");
  params.delete("hash");
  const authDate = Number(params.get("auth_date"));
  if (!Number.isFinite(authDate) || Math.floor(Date.now()/1000) - authDate > 86400 || authDate > Math.floor(Date.now()/1000) + 60) {
    throw new Error("Срок действия initData истёк");
  }
  const dataCheckString = [...params.entries()].sort(([a],[b]) => a.localeCompare(b)).map(([k,v]) => `${k}=${v}`).join("\n");
  const secret = crypto.createHmac("sha256", "WebAppData").update(botToken).digest();
  const calculated = crypto.createHmac("sha256", secret).update(dataCheckString).digest("hex");
  const a = Buffer.from(calculated, "hex"), b = Buffer.from(hash, "hex");
  if (a.length !== b.length || !crypto.timingSafeEqual(a,b)) throw new Error("Неверная подпись Telegram initData");
  const user = JSON.parse(params.get("user") || "null");
  if (!user?.id) throw new Error("Не найден Telegram user");
  return user;
}
