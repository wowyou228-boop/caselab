import Database from "better-sqlite3";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
export const db = new Database(path.resolve(here, "../data.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS Users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  telegram_id TEXT UNIQUE NOT NULL,
  username TEXT,
  first_name TEXT NOT NULL,
  photo_url TEXT,
  balance INTEGER NOT NULL DEFAULT 1000,
  cases_opened INTEGER NOT NULL DEFAULT 0,
  upgrades_won INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS Items (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, rarity TEXT NOT NULL,
  price INTEGER NOT NULL, emoji TEXT NOT NULL, description TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS Cases (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, price INTEGER NOT NULL,
  emoji TEXT NOT NULL, description TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS CaseItems (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  case_id TEXT NOT NULL REFERENCES Cases(id),
  item_id TEXT NOT NULL REFERENCES Items(id),
  weight REAL NOT NULL CHECK(weight > 0)
);
CREATE TABLE IF NOT EXISTS UserInventory (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES Users(id),
  item_id TEXT NOT NULL REFERENCES Items(id),
  acquired_from TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS Openings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES Users(id),
  case_id TEXT NOT NULL REFERENCES Cases(id),
  item_id TEXT NOT NULL REFERENCES Items(id),
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS UpgradeHistory (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES Users(id),
  from_item TEXT NOT NULL,
  to_item TEXT NOT NULL,
  success INTEGER NOT NULL,
  chance REAL NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

const items = [
  ["coin","Медная монета","Common",8,"🪙"],["sprout","Кибер-росток","Common",12,"🌱"],
  ["pixel","Пиксельный куб","Common",20,"🧊"],["neon","Неоновая маска","Rare",65,"🎭"],
  ["blade","Энергоклинок","Rare",95,"🗡️"],["visor","Голографический визор","Rare",130,"🥽"],
  ["drone","Дрон-разведчик","Epic",260,"🛸"],["crystal","Кристалл пустоты","Epic",420,"💎"],
  ["phoenix","Феникс 2099","Epic",700,"🔥"],["crown","Корона императора","Legendary",1800,"👑"],
  ["dragon","Дракон из золота","Legendary",3200,"🐉"],["singularity","Сингулярность","Legendary",6000,"🌌"]
];
const cases = [
  ["starter","Стартовый",10,"🎁","Первый шаг к коллекции"],
  ["cyber","Кибер-ящик",50,"🤖","Технологии и неон"],
  ["vault","Золотой сейф",150,"🔐","Артефакты высокой ценности"],
  ["luck","Охотник за удачей",300,"🎯","Рискни ради легендарного дропа"],
  ["royal","Королевский сундук",1000,"👑","Только эпические и легендарные предметы"]
];
const weights = {
 starter: [["coin",35],["sprout",35],["neon",15],["blade",10],["drone",5]],
 cyber: [["coin",20],["sprout",15],["pixel",15],["neon",20],["blade",10],["visor",5],["drone",3],["crystal",4],["phoenix",5],["crown",2],["dragon",1]],
 vault: [["neon",10],["blade",10],["visor",10],["drone",20],["crystal",20],["phoenix",10],["crown",12],["dragon",8]],
 luck: [["coin",20],["sprout",20],["pixel",20],["crown",20],["dragon",12],["singularity",8]],
 royal: [["drone",20],["crystal",25],["phoenix",25],["crown",15],["dragon",10],["singularity",5]]
};
const seed = db.transaction(() => {
  const insertItem = db.prepare("INSERT OR IGNORE INTO Items(id,name,rarity,price,emoji) VALUES(?,?,?,?,?)");
  items.forEach(x => insertItem.run(...x));
  const insertCase = db.prepare("INSERT OR IGNORE INTO Cases(id,name,price,emoji,description) VALUES(?,?,?,?,?)");
  cases.forEach(x => insertCase.run(...x));
  const insertWeight = db.prepare("INSERT INTO CaseItems(case_id,item_id,weight) SELECT ?,?,?,? WHERE NOT EXISTS (SELECT 1 FROM CaseItems WHERE case_id=? AND item_id=?)");
  for (const [caseId, rows] of Object.entries(weights)) for (const [itemId, weight] of rows) {
    db.prepare("INSERT OR IGNORE INTO CaseItems(case_id,item_id,weight) VALUES(?,?,?)").run(caseId,itemId,weight);
  }
});
seed();
