import "dotenv/config";
import express from "express";
import cors from "cors";
import rateLimit from "express-rate-limit";
import crypto from "node:crypto";
import { db } from "./db.js";
import { verifyTelegramInitData } from "./telegram.js";

const app = express();
app.use(cors({ origin: process.env.CLIENT_ORIGIN?.split(",") || "http://localhost:5173" }));
app.use(express.json({ limit: "32kb" }));
app.use("/api", rateLimit({ windowMs: 60_000, limit: 90, standardHeaders: true, legacyHeaders: false }));

const items = () => db.prepare("SELECT * FROM Items").all();
const cases = () => db.prepare("SELECT c.*, COUNT(ci.item_id) item_count FROM Cases c JOIN CaseItems ci ON ci.case_id=c.id GROUP BY c.id").all();
function weightedPick(rows) {
  const total = rows.reduce((s,r)=>s+r.weight,0);
  let roll = crypto.randomInt(0, 1_000_000) / 1_000_000 * total;
  for (const row of rows) { roll -= row.weight; if (roll < 0) return row; }
  return rows.at(-1);
}
function auth(req,res,next) {
  const id = req.header("x-user-id");
  if (!id || !db.prepare("SELECT id FROM Users WHERE id=?").get(id)) return res.status(401).json({error:"Не авторизован"});
  req.userId = Number(id); next();
}
app.post("/api/auth", (req,res) => {
  try {
    let user;
    if (process.env.BOT_TOKEN && req.body.initData) user = verifyTelegramInitData(req.body.initData, process.env.BOT_TOKEN);
    else if (process.env.NODE_ENV !== "production") user = {id: 999001, first_name:"Demo игрок", username:"demo_player", photo_url:null};
    else return res.status(401).json({error:"Telegram auth required"});
    db.prepare(`INSERT INTO Users(telegram_id,username,first_name,photo_url) VALUES(?,?,?,?)
      ON CONFLICT(telegram_id) DO UPDATE SET username=excluded.username, first_name=excluded.first_name, photo_url=excluded.photo_url`)
      .run(String(user.id),user.username||null,user.first_name||"Игрок",user.photo_url||null);
    const saved = db.prepare("SELECT * FROM Users WHERE telegram_id=?").get(String(user.id));
    res.json({user:saved});
  } catch(e) { res.status(401).json({error:e.message}); }
});
app.get("/api/cases", (req,res) => {
  const data = cases().map(c=>({...c, items:db.prepare(`SELECT i.*,ci.weight FROM CaseItems ci JOIN Items i ON i.id=ci.item_id WHERE ci.case_id=?`).all(c.id)}));
  res.json({cases:data});
});
app.get("/api/me", auth, (req,res) => {
  const user = db.prepare("SELECT * FROM Users WHERE id=?").get(req.userId);
  const inventory = db.prepare(`SELECT ui.id inventoryId,ui.created_at,i.* FROM UserInventory ui JOIN Items i ON i.id=ui.item_id WHERE ui.user_id=? ORDER BY ui.id DESC`).all(req.userId);
  const best = db.prepare(`SELECT MAX(i.price) price FROM UserInventory ui JOIN Items i ON i.id=ui.item_id WHERE ui.user_id=?`).get(req.userId)?.price || 0;
  res.json({user,inventory,stats:{casesOpened:user.cases_opened,upgradesWon:user.upgrades_won,bestDrop:best}});
});
app.post("/api/cases/open", auth, (req,res) => {
  const run = db.transaction(() => {
    const c = db.prepare("SELECT * FROM Cases WHERE id=?").get(req.body.caseId);
    if (!c) throw new Error("Кейс не найден");
    const u = db.prepare("SELECT balance FROM Users WHERE id=?").get(req.userId);
    if (u.balance < c.price) throw new Error("Недостаточно монет");
    db.prepare("UPDATE Users SET balance=balance-?,cases_opened=cases_opened+1 WHERE id=?").run(c.price,req.userId);
    const won = weightedPick(db.prepare("SELECT i.*,ci.weight FROM CaseItems ci JOIN Items i ON i.id=ci.item_id WHERE ci.case_id=?").all(c.id));
    const result = db.prepare("INSERT INTO Openings(user_id,case_id,item_id) VALUES(?,?,?)").run(req.userId,c.id,won.id);
    return {openingId:Number(result.lastInsertRowid),item:won,balance:u.balance-c.price};
  });
  try { res.json(run()); } catch(e) { res.status(400).json({error:e.message}); }
});
app.post("/api/inventory/claim", auth, (req,res) => {
  try {
    const run = db.transaction(() => {
      const o = db.prepare("SELECT * FROM Openings WHERE id=? AND user_id=? AND status='pending'").get(req.body.openingId,req.userId);
      if (!o) throw new Error("Выигрыш уже забран или не найден");
      db.prepare("INSERT INTO UserInventory(user_id,item_id,acquired_from) VALUES(?,?,?)").run(req.userId,o.item_id,"case");
      db.prepare("UPDATE Openings SET status='claimed' WHERE id=?").run(o.id);
      return db.prepare("SELECT i.* FROM Items i WHERE i.id=?").get(o.item_id);
    });
    res.json({item:run()});
  } catch(e) { res.status(400).json({error:e.message}); }
});
app.post("/api/openings/sell", auth, (req,res) => {
  try {
    const run = db.transaction(() => {
      const o = db.prepare("SELECT op.id,op.item_id,i.price FROM Openings op JOIN Items i ON i.id=op.item_id WHERE op.id=? AND op.user_id=? AND op.status='pending'").get(req.body.openingId,req.userId);
      if (!o) throw new Error("Выигрыш уже обработан или не найден");
      db.prepare("UPDATE Openings SET status='sold' WHERE id=?").run(o.id);
      db.prepare("UPDATE Users SET balance=balance+? WHERE id=?").run(o.price,req.userId);
      return {price:o.price,balance:db.prepare("SELECT balance FROM Users WHERE id=?").get(req.userId).balance};
    });
    res.json(run());
  } catch(e) { res.status(400).json({error:e.message}); }
});
app.post("/api/inventory/sell", auth, (req,res) => {
  try {
    const run = db.transaction(() => {
      const row = db.prepare("SELECT ui.id,i.price FROM UserInventory ui JOIN Items i ON i.id=ui.item_id WHERE ui.id=? AND ui.user_id=?").get(req.body.inventoryId,req.userId);
      if (!row) throw new Error("Предмет не найден");
      db.prepare("DELETE FROM UserInventory WHERE id=?").run(row.id);
      db.prepare("UPDATE Users SET balance=balance+? WHERE id=?").run(row.price,req.userId);
      return db.prepare("SELECT balance FROM Users WHERE id=?").get(req.userId).balance;
    });
    res.json({balance:run()});
  } catch(e) { res.status(400).json({error:e.message}); }
});
app.post("/api/upgrade", auth, (req,res) => {
  try {
    const run = db.transaction(() => {
      const own = db.prepare("SELECT ui.id inventoryId,i.* FROM UserInventory ui JOIN Items i ON i.id=ui.item_id WHERE ui.id=? AND ui.user_id=?").get(req.body.inventoryId,req.userId);
      const target = db.prepare("SELECT * FROM Items WHERE id=?").get(req.body.targetItemId);
      if (!own || !target) throw new Error("Предмет не найден");
      if (target.price <= own.price) throw new Error("Целевой предмет должен быть дороже");
      const chance = Math.max(5,Math.min(80,(own.price/target.price)*90));
      const success = crypto.randomInt(0,1_000_000) < chance*10_000;
      db.prepare("DELETE FROM UserInventory WHERE id=?").run(own.inventoryId);
      if (success) {
        db.prepare("INSERT INTO UserInventory(user_id,item_id,acquired_from) VALUES(?,?,?)").run(req.userId,target.id,"upgrade");
        db.prepare("UPDATE Users SET upgrades_won=upgrades_won+1 WHERE id=?").run(req.userId);
      }
      db.prepare("INSERT INTO UpgradeHistory(user_id,from_item,to_item,success,chance) VALUES(?,?,?,?,?)").run(req.userId,own.id,target.id,success?1:0,chance);
      return {success,chance,item:success?target:null};
    });
    res.json(run());
  } catch(e) { res.status(400).json({error:e.message}); }
});
app.post("/api/dev/topup", auth, (req,res) => {
  if (process.env.NODE_ENV === "production") return res.status(403).json({error:"Disabled"});
  const result = db.prepare("UPDATE Users SET balance=balance+500 WHERE id=?").run(req.userId);
  res.json({balance:db.prepare("SELECT balance FROM Users WHERE id=?").get(req.userId).balance});
});
app.get("/api/items", (req,res)=>res.json({items:items()}));
app.get("/api/health", (_,res)=>res.json({ok:true}));
const port = Number(process.env.PORT || 3001);
app.listen(port,()=>console.log(`API listening on http://localhost:${port}`));
