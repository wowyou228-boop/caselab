import React,{useEffect,useMemo,useState} from "react";
import WebApp from "@twa-dev/sdk";
import {motion,AnimatePresence} from "framer-motion";
import {Package,ArrowLeftRight,User,Coins,Plus,ArrowUpRight,ShoppingBag,X, Sparkles, Zap, Trophy} from "lucide-react";

const rarityColor={Common:"#94a3b8",Rare:"#38bdf8",Epic:"#c084fc",Legendary:"#fbbf24"};
const money=n=>new Intl.NumberFormat("ru-RU").format(n);
async function api(path,method="GET",body,uid){
 const r=await fetch("/api"+path,{method,headers:{"Content-Type":"application/json",...(uid?{"x-user-id":uid}:{})},...(body?{body:JSON.stringify(body)}:{})});
 const d=await r.json();if(!r.ok)throw new Error(d.error||"Ошибка запроса");return d;
}
function App(){
 const [user,setUser]=useState(null),[inventory,setInventory]=useState([]),[stats,setStats]=useState({}),[cases,setCases]=useState([]),[items,setItems]=useState([]);
 const [tab,setTab]=useState("cases"),[busy,setBusy]=useState(false),[notice,setNotice]=useState("");
 const [pending,setPending]=useState(null),[selectedOwn,setSelectedOwn]=useState(null),[target,setTarget]=useState(null),[upgradeResult,setUpgradeResult]=useState(null);
 const uid=user?.id;
 const haptic=(type="light")=>{try{WebApp.HapticFeedback?.impactOccurred(type)}catch{}};
 async function refresh(id=uid){if(!id)return;const d=await api("/me","GET",null,id);setUser(d.user);setInventory(d.inventory);setStats(d.stats)}
 useEffect(()=>{(async()=>{try{
   try{WebApp.ready();WebApp.expand();WebApp.setHeaderColor("#0f172a");WebApp.setBackgroundColor("#0f172a")}catch{}
   const a=await api("/auth","POST",{initData:WebApp.initData||""});setUser(a.user);
   const [c,i]=await Promise.all([api("/cases"),api("/items")]);setCases(c.cases);setItems(i.items);
   await refresh(a.user.id);
 }catch(e){setNotice(e.message)}})()},[]);
 const toast=m=>{setNotice(m);setTimeout(()=>setNotice(""),2800)};
 async function topup(){try{await api("/dev/topup","POST",{},uid);await refresh();haptic();toast("+500 монет добавлено")}catch(e){toast(e.message)}}
 async function openCase(c){if(busy)return;setBusy(true);setPending(null);try{const d=await api("/cases/open","POST",{caseId:c.id},uid);await refresh();setPending({...d,case:c});haptic("medium")}catch(e){toast(e.message)}finally{setBusy(false)}}
 async function claim(){try{await api("/inventory/claim","POST",{openingId:pending.openingId},uid);setPending(null);await refresh();haptic("medium");toast("Предмет добавлен в инвентарь")}catch(e){toast(e.message)}}
 async function sellPending(){try{const d=await api("/openings/sell","POST",{openingId:pending.openingId},uid);setPending(null);await refresh();haptic();toast(`Продано за ${money(d.price)} монет`)}catch(e){toast(e.message)}}
 async function sell(id){try{await api("/inventory/sell","POST",{inventoryId:id},uid);await refresh();haptic();toast("Предмет продан")}catch(e){toast(e.message)}}
 function sendUpgrade(item){setSelectedOwn(item);setTarget(null);setTab("upgrade")}
 async function upgrade(){if(!selectedOwn||!target||busy)return;setBusy(true);setUpgradeResult(null);try{const d=await api("/upgrade","POST",{inventoryId:selectedOwn.inventoryId,targetItemId:target.id},uid);setUpgradeResult(d);haptic(d.success?"heavy":"rigid");await refresh();setSelectedOwn(null);setTarget(null)}catch(e){toast(e.message)}finally{setBusy(false)}}
 const targets=useMemo(()=>items.filter(i=>selectedOwn&&i.price>selectedOwn.price).sort((a,b)=>a.price-b.price),[items,selectedOwn]);
 const chance=selectedOwn&&target?Math.max(5,Math.min(80,selectedOwn.price/target.price*90)):0;
 return <div className="app-shell">
  <header className="topbar"><div className="brand"><span className="brand-icon">✦</span><div><b>CASE<span>LAB</span></b><small>ОТКРЫВАЙ. СОБИРАЙ. УЛУЧШАЙ.</small></div></div><div className="balance"><Coins size={16}/>{money(user?.balance||0)}</div></header>
  <main>
   {tab==="cases"&&<section><div className="hero"><div className="eyebrow"><Sparkles size={13}/> ТВОЯ УДАЧА НАЧИНАЕТСЯ ЗДЕСЬ</div><h1>Открывай<br/><em>легендарное.</em></h1><p>Пять кейсов. Сотни комбинаций. Один шанс на редкий дроп.</p></div>
    <div className="section-head"><h2>Выбери кейс</h2><span>{cases.length} КЕЙСОВ</span></div>
    <div className="case-grid">{cases.map((c,i)=><motion.article whileTap={{scale:.97}} className={`case-card case-${c.id}`} key={c.id}>
      <div className="case-top"><span className="case-index">0{i+1}</span><span className="case-tag">{c.id==="starter"?"ДЛЯ НОВИЧКОВ":c.id==="luck"?"ВЫСОКИЙ РИСК":"SPECIAL DROP"}</span></div>
      <div className="case-art"><div className="glow"/><motion.div animate={{y:[0,-7,0],rotate:[-3,3,-3]}} transition={{duration:3,repeat:Infinity}}>{c.emoji}</motion.div></div>
      <h3>{c.name}</h3><p>{c.description}</p>
      <div className="case-bottom"><strong>{c.price===0?"БЕСПЛАТНО":`${money(c.price)} 🪙`}</strong><button disabled={busy||user?.balance<c.price} onClick={()=>openCase(c)}>{busy?"...":"Открыть"} <ArrowUpRight size={15}/></button></div>
    </motion.article>)}</div>
   </section>}
   {tab==="upgrade"&&<section><div className="page-title"><div className="eyebrow"><Zap size={13}/> RISK & REWARD</div><h1>Апгрейд</h1><p>Поставь предмет и попробуй получить более ценный.</p></div>
    <div className="upgrade-board">
     <div className="upgrade-slots"><button className="slot" onClick={()=>document.getElementById("own-items")?.scrollIntoView({behavior:"smooth"})}><small>ТВОЙ ПРЕДМЕТ</small>{selectedOwn?<><span className="slot-emoji">{selectedOwn.emoji}</span><b>{selectedOwn.name}</b><span>{money(selectedOwn.price)} 🪙</span></>:<><span className="slot-plus">+</span><b>Выбрать предмет</b></>}</button>
      <div className="versus">VS</div>
      <button className="slot" onClick={()=>document.getElementById("target-items")?.scrollIntoView({behavior:"smooth"})}><small>ЖЕЛАЕМЫЙ ПРЕДМЕТ</small>{target?<><span className="slot-emoji">{target.emoji}</span><b>{target.name}</b><span>{money(target.price)} 🪙</span></>:<><span className="slot-plus">?</span><b>Выбрать цель</b></>}</button></div>
     <div className="wheel-wrap"><div className={`wheel ${busy?"spinning":""}`} style={{"--chance":`${chance*3.6}deg`}}><div className="wheel-center"><strong>{chance?`${chance.toFixed(1)}%`:"—"}</strong><small>ШАНС УСПЕХА</small></div><div className="wheel-pointer"/></div></div>
     <button className="primary-btn" disabled={!selectedOwn||!target||busy} onClick={upgrade}>{busy?"ВРАЩЕНИЕ...":"ЗАПУСТИТЬ АПГРЕЙД"} <Zap size={17}/></button>
     <p className="muted center">Шанс = (цена предмета ÷ цена цели) × 90%, от 5% до 80%.</p>
    </div>
    <div id="own-items" className="section-head"><h2>Твои предметы</h2><span>{inventory.length} ШТ.</span></div>
    <div className="item-grid">{inventory.map(it=><button className={`item-card ${selectedOwn?.inventoryId===it.inventoryId?"chosen":""}`} key={it.inventoryId} onClick={()=>{setSelectedOwn(it);setTarget(null)}} style={{"--rarity":rarityColor[it.rarity]}}><span>{it.emoji}</span><b>{it.name}</b><small>{money(it.price)} 🪙</small></button>)}</div>
    {selectedOwn&&<><div id="target-items" className="section-head"><h2>Выбери цель</h2><span>ДОРОЖЕ ТВОЕГО</span></div><div className="item-grid">{targets.map(it=><button key={it.id} className={`item-card ${target?.id===it.id?"chosen":""}`} onClick={()=>setTarget(it)} style={{"--rarity":rarityColor[it.rarity]}}><span>{it.emoji}</span><b>{it.name}</b><small>{money(it.price)} 🪙</small></button>)}</div></>}
   </section>}
   {tab==="profile"&&<section><div className="profile-card"><div className="profile-avatar">{user?.photo_url?<img src={user.photo_url}/>:<User/>}</div><div className="profile-info"><h2>{user?.first_name||"Игрок"}</h2><p>@{user?.username||"telegram_user"}</p><span className="online-dot"/> <small>TELEGRAM PLAYER</small></div><button className="topup" onClick={topup}><Plus size={15}/> +500</button></div>
    <div className="balance-panel"><div><small>ТВОЙ БАЛАНС</small><strong><Coins size={22}/>{money(user?.balance||0)}</strong></div><button onClick={topup}>Пополнить <Plus size={15}/></button></div>
    <div className="stats-grid"><div><Package/><strong>{stats.casesOpened||0}</strong><small>Кейсов открыто</small></div><div><Trophy/><strong>{stats.upgradesWon||0}</strong><small>Успешных апгрейдов</small></div><div><Sparkles/><strong>{money(stats.bestDrop||0)}</strong><small>Лучший предмет</small></div></div>
    <div className="section-head"><h2>Инвентарь</h2><span>{inventory.length} ПРЕДМЕТОВ</span></div>
    {inventory.length===0?<div className="empty"><ShoppingBag/><b>Пока пусто</b><p>Открой кейс, чтобы получить первый предмет.</p></div>:<div className="inventory-list">{inventory.map(it=><div className="inventory-row" key={it.inventoryId} style={{"--rarity":rarityColor[it.rarity]}}><span className="inv-emoji">{it.emoji}</span><div className="inv-info"><b>{it.name}</b><small>{it.rarity} · {money(it.price)} 🪙</small></div><button title="В апгрейд" onClick={()=>sendUpgrade(it)}><ArrowLeftRight size={17}/></button><button title="Продать" onClick={()=>sell(it.inventoryId)}><Coins size={17}/></button></div>)}</div>}
   </section>}
  </main>
  <nav className="bottom-nav"><button className={tab==="cases"?"active":""} onClick={()=>setTab("cases")}><Package/><span>Кейсы</span></button><button className={tab==="upgrade"?"active":""} onClick={()=>setTab("upgrade")}><Zap/><span>Апгрейд</span></button><button className={tab==="profile"?"active":""} onClick={()=>setTab("profile")}><User/><span>Профиль</span></button></nav>
  <AnimatePresence>{pending&&<motion.div className="modal-backdrop" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}}><motion.div className="modal" initial={{y:30,scale:.9}} animate={{y:0,scale:1}}><button className="close" onClick={()=>setPending(null)}><X/></button><div className="win-burst">✦</div><div className="eyebrow">ТВОЙ ВЫИГРЫШ</div><div className="win-emoji">{pending.item.emoji}</div><h2>{pending.item.name}</h2><span className="rarity" style={{color:rarityColor[pending.item.rarity]}}>{pending.item.rarity}</span><strong className="win-price">{money(pending.item.price)} 🪙</strong><button className="primary-btn" onClick={claim}>Забрать в инвентарь</button><button className="secondary-btn" onClick={sellPending}>Продать сразу за {money(pending.item.price)} монет</button></motion.div></motion.div>}
   {upgradeResult&&<motion.div className="modal-backdrop" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}}><motion.div className="modal" initial={{y:30,scale:.9}} animate={{y:0,scale:1}}><button className="close" onClick={()=>setUpgradeResult(null)}><X/></button><div className="win-emoji">{upgradeResult.success?upgradeResult.item.emoji:"💥"}</div><h2>{upgradeResult.success?"Апгрейд успешен!":"Не повезло..."}</h2><p>{upgradeResult.success?`Ты получил ${upgradeResult.item.name}`:"Предмет сгорел. Попробуй ещё раз."}</p><span className="rarity">{upgradeResult.chance.toFixed(1)}% шанс</span><button className="primary-btn" onClick={()=>setUpgradeResult(null)}>Продолжить</button></motion.div></motion.div>}
  </AnimatePresence>
  {notice&&<div className="toast">{notice}</div>}
 </div>
}
export default App;
